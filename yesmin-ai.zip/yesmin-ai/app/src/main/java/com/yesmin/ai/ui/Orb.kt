package com.yesmin.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.yesmin.ai.voice.OrbState
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun AiOrb(state: OrbState, size: Dp = 160.dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulseSpeed = when (state) {
        OrbState.IDLE -> 3000; OrbState.LISTENING -> 900; OrbState.THINKING -> 1400
        OrbState.SPEAKING -> 600; OrbState.ERROR -> 500
    }
    val pulse by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(pulseSpeed, easing = LinearEasing), RepeatMode.Reverse), label = "p")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (state == OrbState.THINKING) 1500 else 8000, easing = LinearEasing)), label = "s")
    val main = when (state) {
        OrbState.ERROR -> Color(0xFFEF4444)
        OrbState.LISTENING -> Cyan
        OrbState.THINKING -> Violet
        OrbState.SPEAKING -> Blue
        OrbState.IDLE -> Cyan
    }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val c = center
            val r = this.size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(main.copy(alpha = 0.45f), Color.Transparent), c, r), r * pulse, c)
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), main, Violet.copy(alpha = 0.7f)), c, r * 0.5f), r * 0.42f * pulse, c)
            rotate(spin, c) {
                drawCircle(main, r * 0.75f, c, style = Stroke(3f))
                drawArc(Violet, 0f, 90f, false, topLeft = Offset(c.x - r * 0.62f, c.y - r * 0.62f),
                    size = androidx.compose.ui.geometry.Size(r * 1.24f, r * 1.24f), style = Stroke(5f, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable
fun Waveform(active: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "ph")
    Canvas(modifier.fillMaxWidth().height(36.dp)) {
        val bars = 28
        val gap = size.width / bars
        for (i in 0 until bars) {
            val h = if (active) (abs(sin(phase + i * 0.55f)) * 0.9f + 0.1f) * size.height else size.height * 0.08f
            val x = gap * i + gap / 2
            drawLine(Brush.verticalGradient(listOf(Cyan, Violet)), Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2), 5f, StrokeCap.Round)
        }
    }
}
