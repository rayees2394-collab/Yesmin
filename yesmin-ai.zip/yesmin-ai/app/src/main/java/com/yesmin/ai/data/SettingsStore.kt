package com.yesmin.ai.data

import android.content.Context
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "yesmin_prefs")

data class AppSettings(
    val model: String = "gemini-2.5-flash",
    val temperature: Float = 0.8f,
    val language: String = "hi-IN",
    val speechRate: Float = 1.0f,
    val affection: String = "Caring",
    val darkTheme: Boolean = true
)

/**
 * Preferences live in DataStore. The API key is kept in EncryptedSharedPreferences.
 * NOTE: a key stored on-device can still be extracted by someone with root access to
 * the phone. For a production app, proxy Gemini calls through your own backend.
 */
class SettingsStore(private val context: Context) {

    private val modelKey = stringPreferencesKey("model")
    private val tempKey = floatPreferencesKey("temperature")
    private val langKey = stringPreferencesKey("language")
    private val rateKey = floatPreferencesKey("speech_rate")
    private val affectionKey = stringPreferencesKey("affection")
    private val themeKey = stringPreferencesKey("theme")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        val d = AppSettings()
        AppSettings(
            model = p[modelKey] ?: d.model,
            temperature = p[tempKey] ?: d.temperature,
            language = p[langKey] ?: d.language,
            speechRate = p[rateKey] ?: d.speechRate,
            affection = p[affectionKey] ?: d.affection,
            darkTheme = (p[themeKey] ?: "dark") == "dark"
        )
    }

    suspend fun save(s: AppSettings) {
        context.dataStore.edit { p ->
            p[modelKey] = s.model.trim()
            p[tempKey] = s.temperature
            p[langKey] = s.language
            p[rateKey] = s.speechRate
            p[affectionKey] = s.affection
            p[themeKey] = if (s.darkTheme) "dark" else "light"
        }
    }

    private val securePrefs by lazy {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "yesmin_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getApiKey(): String = securePrefs.getString("gemini_api_key", "") ?: ""
    fun setApiKey(key: String) {
        securePrefs.edit().putString("gemini_api_key", key.trim()).apply()
    }
}
