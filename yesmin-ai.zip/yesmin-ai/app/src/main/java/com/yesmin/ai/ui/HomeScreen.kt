package com.yesmin.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.yesmin.ai.actions.AppAction
import com.yesmin.ai.voice.OrbState

@Composable
fun HomeScreen(vm: AppViewModel, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val msgs by vm.chat.collectAsState()
    val orb by vm.orb.collectAsState()
    val busy by vm.busy.collectAsState()
    val conn by vm.connection.collectAsState()
    val voiceErr by vm.voiceError.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening() else vm.voice.let { vm.clearVoiceError() }
    }
    var micDenied by remember { mutableStateOf(false) }

    fun onMic() {
        if (orb == OrbState.LISTENING) { vm.stopListening(); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            micDenied = false; vm.startListening()
        } else {
            micDenied = true
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(
                when (conn) { Connection.CONNECTED -> Color(0xFF22C55E); Connection.ERROR -> Color(0xFFEF4444); else -> Color.Gray }, CircleShape))
            Text("  YESMIN AI · " + when (conn) { Connection.CONNECTED -> "Gemini connected"; Connection.ERROR -> "Gemini error"; else -> "Gemini not tested" },
                color = Color.Gray, modifier = Modifier.weight(1f))
            IconButton(onClick = { go("settings") }) { Icon(Icons.Filled.Settings, "Settings", tint = Cyan) }
        }

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AiOrb(orb) }
        Waveform(active = orb == OrbState.SPEAKING)
        Text(
            when (orb) { OrbState.IDLE -> "Haan, main yahin hoon"; OrbState.LISTENING -> "Sun rahi hoon…"
                OrbState.THINKING -> "Soch rahi hoon…"; OrbState.SPEAKING -> "Bol rahi hoon…"; OrbState.ERROR -> "Kuch gadbad hui" },
            color = Cyan, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 4.dp)
        )

        LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (msgs.isEmpty()) item {
                Text("Namaste! 'Hello Yesmin' bolo ya kuch type karo. Pehle Settings mein Gemini API key daalna mat bhoolna.", color = Color.Gray)
            }
            items(msgs, key = { it.id }) { m -> Bubble(m.text, m.role == "user") }
            if (busy) item { Text("…", color = Violet) }
        }

        voiceErr?.let { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(e, color = Color(0xFFFCA5A5), modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.clearVoiceError() }) { Text("OK") }
            }
        }
        if (micDenied && orb == OrbState.IDLE && voiceErr == null) {
            Text("Mic permission do taaki main sun sakun. Type karke bhi baat kar sakte ho.", color = Color.Gray)
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            QuickAction(Icons.Filled.PlayCircle, "YouTube") { vm.quickAction(AppAction.OpenYouTube) }
            QuickAction(Icons.Filled.Apps, "Apps") { go("apps") }
            QuickAction(Icons.Filled.Code, "Coding") { go("code") }
            QuickAction(Icons.Filled.CameraAlt, "Camera") { vm.quickAction(AppAction.OpenCamera) }
            QuickAction(Icons.Filled.StickyNote2, "Notes") { go("notes") }
            QuickAction(Icons.Filled.Build, "Tools") { go("tools") }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onMic() }) {
                Icon(Icons.Filled.Mic, "Mic", tint = if (orb == OrbState.LISTENING) Color(0xFFEF4444) else Cyan)
            }
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Yesmin se baat karo…") }, maxLines = 3
            )
            if (busy) {
                IconButton(onClick = { vm.cancelRequest() }) { Icon(Icons.Filled.Stop, "Cancel request", tint = Violet) }
            } else {
                IconButton(onClick = { vm.sendChat(input); input = "" }) { Icon(Icons.Filled.Send, "Send", tint = Cyan) }
            }
            IconButton(onClick = { vm.stopSpeaking() }) { Icon(Icons.Filled.VolumeOff, "Stop speaking", tint = Color.Gray) }
            IconButton(onClick = { vm.retryLast() }) { Icon(Icons.Filled.Refresh, "Retry", tint = Color.Gray) }
        }
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(46.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(icon, label, tint = Cyan) }
        Text(label, color = Color.Gray, style = androidx.compose.material3.MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Bubble(text: String, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Text(
            text, color = Color.White,
            modifier = Modifier.background(if (mine) Violet.copy(alpha = 0.55f) else Panel, RoundedCornerShape(14.dp)).padding(10.dp)
        )
    }
}
