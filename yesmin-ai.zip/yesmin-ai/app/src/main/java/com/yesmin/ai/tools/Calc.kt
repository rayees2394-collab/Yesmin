package com.yesmin.ai.tools

/** Offline calculator: + - * / % ^ and parentheses. */
object Calc {
    fun eval(src: String): Result<Double> = runCatching {
        Parser(src.replace(" ", "").replace("×", "*").replace("÷", "/")).parse()
    }

    fun format(v: Double): String =
        if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else "%.10g".format(v).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double {
            if (s.isEmpty()) error("Kuch likho")
            val v = expr()
            if (i < s.length) error("Samajh nahi aaya: '${s[i]}'")
            return v
        }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]; val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = power()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                val op = s[i++]; val r = power()
                v = when (op) {
                    '*' -> v * r
                    '/' -> { if (r == 0.0) error("Zero se divide nahi hota"); v / r }
                    else -> v % r
                }
            }
            return v
        }
        fun power(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, power()) }
            return b
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (i < s.length && s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') error("')' missing hai")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) error("Number chahiye")
            return s.substring(st, i).toDouble()
        }
    }
}

object Units {
    val categories: Map<String, List<Pair<String, Double>>> = mapOf(
        "Length" to listOf("m" to 1.0, "km" to 1000.0, "cm" to 0.01, "mm" to 0.001, "mile" to 1609.344, "ft" to 0.3048, "inch" to 0.0254),
        "Weight" to listOf("kg" to 1.0, "g" to 0.001, "lb" to 0.45359237, "oz" to 0.028349523125),
        "Volume" to listOf("L" to 1.0, "mL" to 0.001, "gal(US)" to 3.785411784, "cup" to 0.2365882365),
        "Temperature" to listOf("C" to 0.0, "F" to 0.0, "K" to 0.0)
    )

    fun convert(cat: String, value: Double, from: String, to: String): Double {
        if (cat == "Temperature") {
            val c = when (from) { "C" -> value; "F" -> (value - 32) * 5 / 9; else -> value - 273.15 }
            return when (to) { "C" -> c; "F" -> c * 9 / 5 + 32; else -> c + 273.15 }
        }
        val list = categories.getValue(cat)
        val f = list.first { it.first == from }.second
        val t = list.first { it.first == to }.second
        return value * f / t
    }
}
