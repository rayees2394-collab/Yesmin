package com.yesmin.ai.ai

import com.yesmin.ai.data.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ChatTurn(val role: String, val text: String) // role: "user" or "model"

sealed class GeminiResult {
    data class Success(val text: String) : GeminiResult()
    data class Failure(val message: String) : GeminiResult()
}

/** Talks to the Gemini REST API. Knows nothing about UI or Android actions. */
class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(75, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    /**
     * Cancelling the calling coroutine cancels the HTTP call.
     * [jsonMode] asks Gemini to return application/json (used by the action router).
     */
    suspend fun generate(
        apiKey: String,
        settings: AppSettings,
        systemPrompt: String,
        history: List<ChatTurn>,
        jsonMode: Boolean
    ): GeminiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext GeminiResult.Failure("API key set nahi hai. Settings mein Gemini API key daalo.")
        }
        val contents = JSONArray()
        history.forEach { t ->
            contents.put(
                JSONObject()
                    .put("role", t.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
            )
        }
        val gen = JSONObject().put("temperature", settings.temperature.toDouble())
        if (jsonMode) gen.put("responseMimeType", "application/json")

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", gen)

        val url = "https://generativelanguage.googleapis.com/v1beta/models/${settings.model.trim()}:generateContent"
        val request = Request.Builder()
            .url(url)
            .header("x-goog-api-key", apiKey) // never logged
            .post(body.toString().toRequestBody(json))
            .build()

        try {
            val response = client.newCall(request).await()
            response.use { r ->
                val raw = r.body?.string().orEmpty()
                if (!r.isSuccessful) return@withContext GeminiResult.Failure(httpError(r.code, raw))
                val text = JSONObject(raw)
                    .optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text").orEmpty()
                if (text.isBlank()) GeminiResult.Failure("Gemini ne khaali jawab diya (shayad safety filter). Dobara try karo.")
                else GeminiResult.Success(text)
            }
        } catch (e: java.net.SocketTimeoutException) {
            GeminiResult.Failure("Request time out ho gayi. Internet check karke retry karo.")
        } catch (e: java.net.UnknownHostException) {
            GeminiResult.Failure("Internet nahi mil raha. Network check karo.")
        } catch (e: IOException) {
            GeminiResult.Failure("Network error: ${e.javaClass.simpleName}")
        } catch (e: org.json.JSONException) {
            GeminiResult.Failure("Gemini ka response samajh nahi aaya.")
        }
    }

    suspend fun testConnection(apiKey: String, settings: AppSettings): GeminiResult =
        generate(
            apiKey, settings, "Reply with the single word: ok",
            listOf(ChatTurn("user", "ping")), jsonMode = false
        )

    private fun httpError(code: Int, raw: String): String {
        val apiMsg = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }.getOrNull()
        return when (code) {
            400 -> "Request galat hai ya API key invalid hai. ${apiMsg.orEmpty()}".trim()
            401, 403 -> "API key invalid hai ya permission nahi hai."
            404 -> "Model naam nahi mila. Settings mein model name check karo."
            429 -> "Quota/rate limit poori ho gayi. Thodi der baad try karo."
            in 500..599 -> "Gemini server mein dikkat hai. Baad mein retry karo."
            else -> "Error $code ${apiMsg.orEmpty()}".trim()
        }
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!cont.isCancelled) cont.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                cont.resume(response)
            }
        })
    }
}
