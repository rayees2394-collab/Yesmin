package com.yesmin.ai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val Violet = Color(0xFF8B5CF6)
val Blue = Color(0xFF3B82F6)
val Bg = Color(0xFF0A0E1A)
val Panel = Color(0xFF131A2E)

private val Dark = darkColorScheme(
    primary = Cyan, secondary = Violet, tertiary = Blue,
    background = Bg, surface = Panel, onBackground = Color(0xFFE6EDF7), onSurface = Color(0xFFE6EDF7),
    onPrimary = Color.Black
)
private val Light = lightColorScheme(
    primary = Color(0xFF0891B2), secondary = Color(0xFF6D28D9), tertiary = Color(0xFF2563EB)
)

@Composable
fun YesminTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
