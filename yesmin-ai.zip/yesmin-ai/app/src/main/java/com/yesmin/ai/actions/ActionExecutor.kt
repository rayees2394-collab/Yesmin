package com.yesmin.ai.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings

data class ActionResult(val success: Boolean, val message: String)

data class InstalledApp(val label: String, val packageName: String)

class ActionExecutor(private val context: Context) {

    private val pm = context.packageManager

    fun installedApps(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    /** Executes a validated action. Returns the REAL outcome. SaveNote is handled by the caller. */
    fun execute(action: AppAction): ActionResult = when (action) {
        is AppAction.OpenApp -> openByName(action.appName)
        AppAction.OpenYouTube -> openYouTube()
        is AppAction.SearchYouTube -> searchYouTube(action.query)
        is AppAction.OpenBrowser -> start(Intent(Intent.ACTION_VIEW, Uri.parse(action.url)), "Browser")
        is AppAction.OpenDialer -> start(
            Intent(Intent.ACTION_DIAL, action.number?.let { Uri.parse("tel:" + Uri.encode(it)) } ?: Uri.parse("tel:")),
            "Dialer"
        )
        is AppAction.OpenMaps -> start(
            Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(action.query))), "Maps"
        )
        AppAction.OpenCamera -> start(Intent(MediaStore.ACTION_IMAGE_CAPTURE), "Camera")
        is AppAction.OpenSettings -> start(Intent(settingsAction(action.section)), "Settings")
        is AppAction.SaveNote -> ActionResult(true, "Note save ho gaya.")
    }

    fun openPackage(pkg: String): ActionResult {
        val launch = pm.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "Yeh app installed nahi hai ya khul nahi sakta.")
        return start(launch, pkg)
    }

    private fun openByName(name: String): ActionResult {
        val q = name.lowercase()
        val match = installedApps().firstOrNull { it.label.lowercase() == q }
            ?: installedApps().firstOrNull { it.label.lowercase().contains(q) }
            ?: return ActionResult(false, "'$name' naam ka app installed nahi mila.")
        return openPackage(match.packageName)
    }

    private fun openYouTube(): ActionResult {
        val pkg = "com.google.android.youtube"
        return if (pm.getLaunchIntentForPackage(pkg) != null) openPackage(pkg)
        else start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")), "YouTube (browser)")
    }

    private fun searchYouTube(query: String): ActionResult {
        val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
        val intent = Intent(Intent.ACTION_VIEW, uri)
        if (pm.getLaunchIntentForPackage("com.google.android.youtube") != null) {
            intent.setPackage("com.google.android.youtube")
        }
        return start(intent, "YouTube search")
    }

    private fun settingsAction(section: String) = when (section) {
        "WIFI" -> Settings.ACTION_WIFI_SETTINGS
        "BLUETOOTH" -> Settings.ACTION_BLUETOOTH_SETTINGS
        "DISPLAY" -> Settings.ACTION_DISPLAY_SETTINGS
        "SOUND" -> Settings.ACTION_SOUND_SETTINGS
        "BATTERY" -> Intent.ACTION_POWER_USAGE_SUMMARY
        "APPS" -> Settings.ACTION_APPLICATION_SETTINGS
        "LOCATION" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        else -> Settings.ACTION_SETTINGS
    }

    private fun start(intent: Intent, label: String): ActionResult = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        ActionResult(true, "$label launch ho gaya.")
    } catch (e: ActivityNotFoundException) {
        ActionResult(false, "$label ke liye koi app nahi mila.")
    } catch (e: SecurityException) {
        ActionResult(false, "$label kholne ki permission nahi hai.")
    }
}
