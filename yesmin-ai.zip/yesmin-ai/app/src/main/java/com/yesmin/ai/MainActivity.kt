package com.yesmin.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.yesmin.ai.ui.AppViewModel
import com.yesmin.ai.ui.AppsScreen
import com.yesmin.ai.ui.CodeScreen
import com.yesmin.ai.ui.HomeScreen
import com.yesmin.ai.ui.NotesScreen
import com.yesmin.ai.ui.SettingsScreen
import com.yesmin.ai.ui.ToolsScreen
import com.yesmin.ai.ui.AiOrb
import com.yesmin.ai.ui.Cyan
import com.yesmin.ai.voice.OrbState
import kotlinx.coroutines.delay
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Alignment as Align
import com.yesmin.ai.ui.YesminTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings by vm.settings.collectAsState()
            YesminTheme(settings.darkTheme) { Root(vm) }
        }
    }
}

@Composable
private fun Root(vm: AppViewModel) {
    var screen by remember { mutableStateOf("home") }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1400); splash = false }
    if (splash) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Align.CenterHorizontally) {
                AiOrb(OrbState.THINKING)
                Text("YESMIN AI", color = Cyan, style = MaterialTheme.typography.headlineMedium)
            }
        }
        return
    }
    val status by vm.status.collectAsState()
    val snack = remember { SnackbarHostState() }

    BackHandler(enabled = screen != "home") { screen = "home" }
    LaunchedEffect(status) {
        status?.let { snack.showSnackbar(it); vm.clearStatus() }
    }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        when (screen) {
            "apps" -> AppsScreen(vm)
            "code" -> CodeScreen(vm)
            "notes" -> NotesScreen(vm)
            "tools" -> ToolsScreen()
            "settings" -> SettingsScreen(vm)
            else -> HomeScreen(vm) { screen = it }
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter)) { Snackbar(it) }
    }
}
