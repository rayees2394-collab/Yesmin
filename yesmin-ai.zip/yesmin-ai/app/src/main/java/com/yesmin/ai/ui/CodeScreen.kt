package com.yesmin.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val languages = listOf("Kotlin", "Java", "XML", "Python", "JavaScript", "HTML", "CSS", "C++", "Bash")
private val fence = Regex("```([a-zA-Z0-9+#]*)\\n(.*?)```", RegexOption.DOT_MATCHES_ALL)
private val keywords = Regex(
    "\\b(fun|val|var|class|object|interface|return|if|else|for|while|when|import|package|private|public|static|void|int|def|from|const|let|function|new|null|true|false|try|catch|override|suspend|in|is|this|self)\\b"
)
private val strings = Regex("\"(\\\\.|[^\"\\\\])*\"|'(\\\\.|[^'\\\\])*'")
private val comments = Regex("//.*|#.*")

fun highlight(code: String): AnnotatedString = buildAnnotatedString {
    append(code)
    keywords.findAll(code).forEach { addStyle(SpanStyle(color = Violet), it.range.first, it.range.last + 1) }
    strings.findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFF86EFAC)), it.range.first, it.range.last + 1) }
    comments.findAll(code).forEach { addStyle(SpanStyle(color = Color(0xFF94A3B8)), it.range.first, it.range.last + 1) }
}

@Composable
private fun AssistantBlocks(text: String, defaultLang: String, vm: AppViewModel) {
    val clip = LocalClipboardManager.current
    val matches = fence.findAll(text).toList()
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        var last = 0
        matches.forEach { match ->
            val before = text.substring(last, match.range.first).trim()
            if (before.isNotEmpty()) Text(before, color = Color.White)
            last = match.range.last + 1
            val code = match.groupValues[2].trimEnd()
            val l = match.groupValues[1].ifBlank { defaultLang }
            Column(Modifier.fillMaxWidth().background(Color(0xFF0F172A), RoundedCornerShape(10.dp)).padding(8.dp)) {
                Text(l, color = Color.Gray, fontSize = 11.sp)
                Text(
                    highlight(code), color = Color(0xFFE2E8F0), fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                )
                Row {
                    TextButton(onClick = { clip.setText(AnnotatedString(code)) }) { Text("Copy") }
                    TextButton(onClick = { vm.saveSnippet(l, code) }) { Text("Save") }
                    TextButton(onClick = { vm.sendCode("Is code ko step-by-step explain karo.", defaultLang, code) }) { Text("Explain") }
                }
            }
        }
        val tail = text.substring(last).trim()
        if (tail.isNotEmpty()) Text(tail, color = Color.White)
    }
}

@Composable
fun CodeScreen(vm: AppViewModel) {
    val msgs by vm.code.collectAsState()
    val busy by vm.busy.collectAsState()
    var lang by remember { mutableStateOf("Kotlin") }
    var prompt by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Coding Assistant", color = Cyan, style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            languages.forEach { l -> FilterChip(selected = lang == l, onClick = { lang = l }, label = { Text(l) }) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs, key = { it.id }) { m ->
                if (m.role == "user") Bubble(m.text, true) else AssistantBlocks(m.text, lang, vm)
            }
        }
        OutlinedTextField(
            pasted, { pasted = it }, Modifier.fillMaxWidth(), label = { Text("Code paste karo (optional)") },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp), maxLines = 4
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(prompt, { prompt = it }, Modifier.weight(1f), label = { Text("Kya banana/fix karna hai?") }, maxLines = 3)
            if (busy) Button(onClick = { vm.cancelRequest() }) { Text("Stop") }
            else Button(onClick = { vm.sendCode(prompt, lang, pasted); prompt = "" }) { Text("Go") }
        }
        Text("Note: YESMIN code run/compile nahi karti; generated code ko khud review karke chalao.", color = Color.Gray, fontSize = 11.sp)
    }
}
