package com.yesmin.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.yesmin.ai.data.AppSettings

private val langs = listOf("hi-IN" to "Hindi", "en-IN" to "English (IN)", "en-US" to "English (US)")
private val levels = listOf("Professional", "Friendly", "Caring", "Playful")

@Composable
private fun Section(title: String) =
    Text(title, color = Cyan, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val saved by vm.settings.collectAsState()
    val busy by vm.busy.collectAsState()
    val conn by vm.connection.collectAsState()

    var key by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var model by remember(saved) { mutableStateOf(saved.model) }
    var temp by remember(saved) { mutableStateOf(saved.temperature) }
    var lang by remember(saved) { mutableStateOf(saved.language) }
    var rate by remember(saved) { mutableStateOf(saved.speechRate) }
    var level by remember(saved) { mutableStateOf(saved.affection) }
    var dark by remember(saved) { mutableStateOf(saved.darkTheme) }
    var confirmWipe by remember { mutableStateOf(false) }

    fun current() = AppSettings(model, temp, lang, rate, level, dark)

    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())) {
        Text("Settings", color = Cyan, style = MaterialTheme.typography.titleLarge)

        Section("Gemini API")
        OutlinedTextField(
            key, { key = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(if (vm.hasApiKey()) "API key (saved — naya daalo to replace hoga)" else "Gemini API key") },
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation()
        )
        TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide key" else "Show key") }
        OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Model name") })
        Text("Creativity: " + "%.1f".format(temp), color = Color.Gray)
        Slider(temp, { temp = it }, valueRange = 0f..2f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(enabled = !busy, onClick = { vm.testConnection(current(), key) }) { Text("Test Connection") }
            Text(
                when (conn) { Connection.CONNECTED -> "Connected"; Connection.ERROR -> "Error"; else -> "Not tested" },
                color = when (conn) { Connection.CONNECTED -> Color(0xFF22C55E); Connection.ERROR -> Color(0xFFEF4444); else -> Color.Gray }
            )
        }
        Text(
            "Note: API key is phone par encrypted store hoti hai, lekin rooted phone ya APK tampering se nikal sakti hai. " +
                "Production app mein apne backend se Gemini call karo.",
            color = Color.Gray, style = MaterialTheme.typography.bodySmall
        )

        Section("Personality")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            levels.forEach { l -> FilterChip(selected = level == l, onClick = { level = l }, label = { Text(l) }) }
        }

        Section("Voice & language")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            langs.forEach { (tag, name) -> FilterChip(selected = lang == tag, onClick = { lang = tag }, label = { Text(name) }) }
        }
        Text("Speech rate: " + "%.1f".format(rate), color = Color.Gray)
        Slider(rate, { rate = it }, valueRange = 0.5f..2f)

        Section("Theme")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dark mode", color = Color.White, modifier = Modifier.weight(1f))
            Switch(dark, { dark = it })
        }

        Button(onClick = { vm.saveSettings(current(), key); key = "" }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text("Save Settings")
        }

        Section("Privacy & data")
        OutlinedButton(onClick = { vm.clearChatHistory() }, modifier = Modifier.fillMaxWidth()) { Text("Clear chat history") }
        OutlinedButton(onClick = { confirmWipe = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete all local data") }
        if (confirmWipe) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Chat, notes, snippets, searches sab delete honge. Pakka?", color = Color(0xFFFCA5A5), modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.clearAllLocalData(); confirmWipe = false }) { Text("Haan") }
                TextButton(onClick = { confirmWipe = false }) { Text("Nahi") }
            }
        }
        Text("Messages Gemini ko bheje jaate hain jab tum chat karte ho. Voice recognition phone ki speech service use karti hai (kuch devices par Google ke server).",
            color = Color.Gray, style = MaterialTheme.typography.bodySmall)

        Section("Permissions")
        val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        Text("Microphone: " + if (mic) "granted" else "not granted", color = Color.White)
        Text("Internet: granted (manifest)", color = Color.White)
        OutlinedButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Open app permissions") }

        Section("Troubleshooting")
        Text(
            "• 'API key invalid' → key dobara paste karo, Test Connection dabao.\n" +
                "• 'Model naam nahi mila' → model name check karo (jaise gemini-2.5-flash).\n" +
                "• Voice nahi chal rahi → phone Settings mein Google speech/TTS engine aur Hindi voice data install karo.\n" +
                "• Quota error → thodi der baad try karo ya naya key use karo.",
            color = Color.Gray, style = MaterialTheme.typography.bodySmall
        )

        Section("About")
        Text("YESMIN AI v0.1.0 (MVP)\nYESMIN ek AI hai, insaan nahi. Gemini se powered.", color = Color.Gray)
    }
}
