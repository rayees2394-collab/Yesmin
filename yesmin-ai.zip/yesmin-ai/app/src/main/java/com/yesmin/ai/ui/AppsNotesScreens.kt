package com.yesmin.ai.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.yesmin.ai.actions.AppAction
import com.yesmin.ai.actions.InstalledApp

@Composable
fun AppsScreen(vm: AppViewModel) {
    val apps by vm.apps.collectAsState()
    val favs by vm.favorites.collectAsState()
    val recent by vm.recentSearches.collectAsState()
    var query by remember { mutableStateOf("") }
    var music by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.loadApps() }

    val shown = apps.filter { it.label.contains(query, ignoreCase = true) }
        .sortedWith(compareByDescending<InstalledApp> { it.packageName in favs }.thenBy { it.label.lowercase() })

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("YouTube / Music search", color = Cyan, style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(music, { music = it }, Modifier.weight(1f), placeholder = { Text("jaise: Arijit Singh songs") }, singleLine = true)
            Button(onClick = { if (music.isNotBlank()) { vm.quickAction(AppAction.SearchYouTube(music.trim())); music = "" } }) { Text("Search") }
        }
        if (recent.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Recent: " + recent.take(3).joinToString(", ") { it.query }, color = Color.Gray, modifier = Modifier.weight(1f), maxLines = 1)
                TextButton(onClick = { vm.clearMusicHistory() }) { Text("Clear") }
            }
        }
        Text("Apps", color = Cyan, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("App search") }, singleLine = true)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            items(shown, key = { it.packageName }) { a ->
                Row(Modifier.fillMaxWidth().clickable { vm.openPackage(a.packageName) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(a.label, color = Color.White, modifier = Modifier.weight(1f))
                    IconButton(onClick = { vm.toggleFavorite(a.packageName) }) {
                        Icon(if (a.packageName in favs) Icons.Filled.Star else Icons.Filled.StarBorder, "Favorite", tint = Cyan)
                    }
                }
            }
        }
    }
}

@Composable
fun NotesScreen(vm: AppViewModel) {
    val notes by vm.notes.collectAsState()
    val snippets by vm.snippets.collectAsState()
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Notes", color = Cyan, style = MaterialTheme.typography.titleLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Naya note…") })
            Button(onClick = { vm.addNote(text); text = "" }) { Text("Add") }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            items(notes, key = { "n" + it.id }) { n ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(n.text, color = Color.White, modifier = Modifier.weight(1f).padding(vertical = 6.dp))
                    IconButton(onClick = { vm.deleteNote(n.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = Color.Gray) }
                }
            }
            if (snippets.isNotEmpty()) item { Text("Saved snippets", color = Cyan, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp)) }
            items(snippets, key = { "s" + it.id }) { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("[${s.language}] " + s.code.take(160), color = Color(0xFFE2E8F0), modifier = Modifier.weight(1f).padding(vertical = 6.dp))
                    IconButton(onClick = { vm.deleteSnippet(s.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = Color.Gray) }
                }
            }
        }
    }
}
