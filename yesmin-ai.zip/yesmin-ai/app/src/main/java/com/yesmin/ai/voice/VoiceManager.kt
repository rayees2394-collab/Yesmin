package com.yesmin.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING, ERROR }

/** Wraps SpeechRecognizer + TextToSpeech. Must be created and used on the main thread. */
class VoiceManager(private val context: Context) {

    private val _state = MutableStateFlow(OrbState.IDLE)
    val state: StateFlow<OrbState> = _state.asStateFlow()

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var langTag = "hi-IN"
    private var rate = 1.0f

    init {
        tts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) applyTtsConfig()
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { _state.value = OrbState.SPEAKING }
            override fun onDone(utteranceId: String?) { _state.value = OrbState.IDLE }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { _state.value = OrbState.ERROR }
        })
    }

    fun configure(languageTag: String, speechRate: Float) {
        langTag = languageTag
        rate = speechRate
        if (ttsReady) applyTtsConfig()
    }

    private fun applyTtsConfig() {
        val t = tts ?: return
        val locale = Locale.forLanguageTag(langTag)
        val r = t.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            _voiceError.value = "Is language ki voice installed nahi hai. Phone ki TTS settings mein voice data install karo."
        }
        t.setSpeechRate(rate)
        // Prefer a female-sounding voice when the engine exposes one (heuristic; engines vary).
        val female = t.voices?.firstOrNull {
            it.locale.language == locale.language && !it.isNetworkConnectionRequired &&
                it.name.contains("female", ignoreCase = true)
        }
        if (female != null) t.voice = female
    }

    fun speak(text: String) {
        if (!ttsReady) {
            _voiceError.value = "Text-to-speech abhi ready nahi hai."
            return
        }
        stopListening()
        tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "yesmin-utt")
    }

    fun stopSpeaking() {
        tts?.stop()
        if (_state.value == OrbState.SPEAKING) _state.value = OrbState.IDLE
    }

    fun setThinking(on: Boolean) {
        if (on) _state.value = OrbState.THINKING
        else if (_state.value == OrbState.THINKING) _state.value = OrbState.IDLE
    }

    fun clearError() { _voiceError.value = null }

    /** Caller must already hold RECORD_AUDIO. */
    fun startListening(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceError.value = "Is phone par speech recognition service available nahi hai."
            _state.value = OrbState.ERROR
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { _state.value = OrbState.LISTENING }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                _state.value = OrbState.IDLE
                if (text.isBlank()) _voiceError.value = "Kuch suna nahi, dobara bolo."
                else onResult(text)
            }
            override fun onError(error: Int) {
                _state.value = OrbState.ERROR
                _voiceError.value = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch samajh nahi aaya, dobara bolo."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service ke liye internet chahiye."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission nahi hai."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai, thodi der baad try karo."
                    else -> "Voice recognition error ($error)."
                }
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    fun stopListening() {
        recognizer?.cancel()
        if (_state.value == OrbState.LISTENING) _state.value = OrbState.IDLE
    }

    fun release() {
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
