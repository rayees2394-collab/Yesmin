package com.yesmin.ai.tools

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yesmin.ai.data.ReminderEntity
import com.yesmin.ai.data.TodoEntity
import com.yesmin.ai.data.YesminDb
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ToolsViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = YesminDb.get(app).dao()

    val todos = dao.todos().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val reminders = dao.reminders().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun addTodo(text: String) { if (text.isNotBlank()) viewModelScope.launch { dao.insertTodo(TodoEntity(text = text.trim())) } }
    fun setDone(t: TodoEntity, done: Boolean) { viewModelScope.launch { dao.setTodoDone(t.id, done) } }
    fun deleteTodo(id: Long) { viewModelScope.launch { dao.deleteTodo(id) } }

    fun addReminder(text: String, minutes: Long) {
        if (text.isBlank() || minutes <= 0) return
        viewModelScope.launch {
            val at = System.currentTimeMillis() + minutes * 60_000
            val id = dao.insertReminder(ReminderEntity(text = text.trim(), triggerAt = at))
            ReminderScheduler.schedule(getApplication(), id, text.trim(), at)
        }
    }

    fun deleteReminder(r: ReminderEntity) {
        viewModelScope.launch {
            ReminderScheduler.cancel(getApplication(), r.id)
            dao.deleteReminder(r.id)
        }
    }
}
