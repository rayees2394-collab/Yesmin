package com.yesmin.ai.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val scope: String,          // "chat" or "code"
    val role: String,           // "user" | "model"
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "snippets")
data class SnippetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val language: String,
    val code: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "music_searches")
data class MusicSearchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "todos")
data class TodoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val done: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val triggerAt: Long
)

@Dao
interface YesminDao {
    @Insert suspend fun insertTodo(t: TodoEntity)
    @Query("SELECT * FROM todos ORDER BY done ASC, id DESC") fun todos(): Flow<List<TodoEntity>>
    @Query("UPDATE todos SET done = :done WHERE id = :id") suspend fun setTodoDone(id: Long, done: Boolean)
    @Query("DELETE FROM todos WHERE id = :id") suspend fun deleteTodo(id: Long)
    @Query("DELETE FROM todos") suspend fun clearTodos()

    @Insert suspend fun insertReminder(r: ReminderEntity): Long
    @Query("SELECT * FROM reminders ORDER BY triggerAt ASC") fun reminders(): Flow<List<ReminderEntity>>
    @Query("DELETE FROM reminders WHERE id = :id") suspend fun deleteReminder(id: Long)
    @Query("DELETE FROM reminders") suspend fun clearReminders()

    @Insert suspend fun insertMessage(m: MessageEntity)
    @Query("SELECT * FROM messages WHERE scope = :scope ORDER BY id ASC")
    fun messages(scope: String): Flow<List<MessageEntity>>
    @Query("DELETE FROM messages WHERE scope = :scope")
    suspend fun clearMessages(scope: String)

    @Insert suspend fun insertNote(n: NoteEntity)
    @Query("SELECT * FROM notes ORDER BY id DESC") fun notes(): Flow<List<NoteEntity>>
    @Query("DELETE FROM notes WHERE id = :id") suspend fun deleteNote(id: Long)

    @Insert suspend fun insertSnippet(s: SnippetEntity)
    @Query("SELECT * FROM snippets ORDER BY id DESC") fun snippets(): Flow<List<SnippetEntity>>
    @Query("DELETE FROM snippets WHERE id = :id") suspend fun deleteSnippet(id: Long)

    @Insert suspend fun insertSearch(s: MusicSearchEntity)
    @Query("SELECT * FROM music_searches ORDER BY id DESC LIMIT 20")
    fun recentSearches(): Flow<List<MusicSearchEntity>>
    @Query("DELETE FROM music_searches") suspend fun clearSearches()

    @Query("DELETE FROM messages") suspend fun clearAllMessages()
    @Query("DELETE FROM notes") suspend fun clearNotes()
    @Query("DELETE FROM snippets") suspend fun clearSnippets()
}

@Database(
    entities = [MessageEntity::class, NoteEntity::class, SnippetEntity::class, MusicSearchEntity::class, TodoEntity::class, ReminderEntity::class],
    version = 2,
    exportSchema = false
)
abstract class YesminDb : RoomDatabase() {
    abstract fun dao(): YesminDao

    companion object {
        @Volatile private var inst: YesminDb? = null
        fun get(context: Context): YesminDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(context.applicationContext, YesminDb::class.java, "yesmin.db")
                .fallbackToDestructiveMigration().build().also { inst = it }
        }
    }
}
