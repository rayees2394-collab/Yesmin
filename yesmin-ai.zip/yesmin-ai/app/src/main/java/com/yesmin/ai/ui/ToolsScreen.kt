package com.yesmin.ai.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yesmin.ai.tools.Calc
import com.yesmin.ai.tools.ToolsViewModel
import com.yesmin.ai.tools.Units
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val tabs = listOf("To-do", "Reminders", "Calculator", "Convert")

@Composable
fun ToolsScreen() {
    var tab by remember { mutableStateOf(0) }
    val tvm: ToolsViewModel = viewModel()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Tools (offline)", color = Cyan, style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            tabs.forEachIndexed { i, t -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) }) }
        }
        when (tab) {
            0 -> TodoTab(tvm)
            1 -> ReminderTab(tvm)
            2 -> CalcTab()
            else -> ConvertTab()
        }
    }
}

@Composable
private fun TodoTab(vm: ToolsViewModel) {
    val todos by vm.todos.collectAsState()
    var text by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("Naya task…") }, singleLine = true)
        Button(onClick = { vm.addTodo(text); text = "" }) { Text("Add") }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        items(todos, key = { it.id }) { t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(t.done, { vm.setDone(t, it) })
                Text(t.text, color = if (t.done) Color.Gray else Color.White, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.deleteTodo(t.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = Color.Gray) }
            }
        }
    }
}

@Composable
private fun ReminderTab(vm: ToolsViewModel) {
    val list by vm.reminders.collectAsState()
    var text by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("10") }
    var info by remember { mutableStateOf<String?>(null) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        info = if (ok) null else "Notification permission nahi mili, isliye reminder dikhega nahi."
    }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("Reminder text") })
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            mins, { mins = it.filter(Char::isDigit).take(5) }, Modifier.weight(1f),
            label = { Text("Kitne minute baad") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            val m = mins.toLongOrNull() ?: 0L
            if (text.isBlank() || m <= 0) info = "Text aur minute (1 ya zyada) daalo."
            else { vm.addReminder(text, m); text = "" }
        }) { Text("Set") }
    }
    info?.let { Text(it, color = Color(0xFFFCA5A5)) }
    Text("Note: reminder phone restart ke baad nahi bachta, aur time approximate hota hai.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
    LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.id }) { r ->
            val past = r.triggerAt < System.currentTimeMillis()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fmt.format(Date(r.triggerAt)) + (if (past) " (ho gaya)" else "") + "  " + r.text,
                    color = if (past) Color.Gray else Color.White, modifier = Modifier.weight(1f).padding(vertical = 6.dp))
                IconButton(onClick = { vm.deleteReminder(r) }) { Icon(Icons.Filled.Delete, "Delete", tint = Color.Gray) }
            }
        }
    }
}

@Composable
private fun CalcTab() {
    var expr by remember { mutableStateOf("") }
    val result = if (expr.isBlank()) null else Calc.eval(expr)
    OutlinedTextField(expr, { expr = it }, Modifier.fillMaxWidth(), label = { Text("jaise: (12+8)*3/4") }, singleLine = true)
    when {
        result == null -> {}
        result.isSuccess -> Text("= " + Calc.format(result.getOrThrow()), color = Cyan, style = MaterialTheme.typography.headlineSmall)
        else -> Text(result.exceptionOrNull()?.message ?: "Error", color = Color(0xFFFCA5A5))
    }
    Text("Supported: + - * / % ^ ( )", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun ConvertTab() {
    var cat by remember { mutableStateOf("Length") }
    val units = Units.categories.getValue(cat).map { it.first }
    var from by remember(cat) { mutableStateOf(units[0]) }
    var to by remember(cat) { mutableStateOf(units[1]) }
    var value by remember { mutableStateOf("1") }
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Units.categories.keys.forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
    }
    OutlinedTextField(
        value, { value = it }, Modifier.fillMaxWidth(), label = { Text("Value") }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
    Text("From", color = Color.Gray)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        units.forEach { u -> FilterChip(selected = from == u, onClick = { from = u }, label = { Text(u) }) }
    }
    Text("To", color = Color.Gray)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        units.forEach { u -> FilterChip(selected = to == u, onClick = { to = u }, label = { Text(u) }) }
    }
    val v = value.toDoubleOrNull()
    if (v == null) Text("Valid number daalo.", color = Color(0xFFFCA5A5))
    else Text("= " + Calc.format(Units.convert(cat, v, from, to)) + " " + to, color = Cyan, style = MaterialTheme.typography.headlineSmall)
}
