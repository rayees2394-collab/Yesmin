package com.yesmin.ai.tools

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.yesmin.ai.MainActivity
import com.yesmin.ai.R

/** Inexact alarms (no SCHEDULE_EXACT_ALARM permission needed). Alarms are lost on reboot. */
object ReminderScheduler {
    private fun pending(ctx: Context, id: Long, text: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", id)
        return PendingIntent.getBroadcast(ctx, id.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context, id: Long, text: String, triggerAt: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending(ctx, id, text))
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, id, ""))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = intent.getStringExtra("text").orEmpty().ifBlank { "Reminder" }
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, "reminders")
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("YESMIN reminder")
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((intent.getLongExtra("id", 0L) % Int.MAX_VALUE).toInt(), n)
    }
}
