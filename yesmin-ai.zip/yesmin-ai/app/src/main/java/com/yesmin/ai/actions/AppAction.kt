package com.yesmin.ai.actions

import org.json.JSONObject

/** Validated, typed actions. Only these can ever be executed. */
sealed class AppAction {
    data class OpenApp(val appName: String) : AppAction()
    object OpenYouTube : AppAction()
    data class SearchYouTube(val query: String) : AppAction()
    data class OpenBrowser(val url: String) : AppAction()
    data class OpenDialer(val number: String?) : AppAction()
    data class OpenMaps(val query: String) : AppAction()
    object OpenCamera : AppAction()
    data class OpenSettings(val section: String) : AppAction()
    data class SaveNote(val text: String) : AppAction()
}

data class ParsedReply(val reply: String, val action: AppAction?, val rejected: String? = null)

/** Treats model output as untrusted: allowlist of types, parameter sanity checks. */
object ActionRouter {

    private val settingsSections = setOf("MAIN", "WIFI", "BLUETOOTH", "DISPLAY", "SOUND", "BATTERY", "APPS", "LOCATION")

    fun parse(raw: String): ParsedReply {
        val obj = runCatching { JSONObject(raw.trim().removePrefix("```json").removeSuffix("```").trim()) }
            .getOrNull() ?: return ParsedReply(raw.trim(), null)

        val reply = obj.optString("reply", "").ifBlank { raw.trim() }
        val a = obj.optJSONObject("action") ?: return ParsedReply(reply, null)

        fun s(k: String, max: Int = 200) = a.optString(k, "").trim().take(max)

        val action: AppAction? = when (a.optString("type")) {
            "OPEN_APP" -> s("appName", 60).takeIf { it.isNotEmpty() }?.let { AppAction.OpenApp(it) }
            "OPEN_YOUTUBE" -> AppAction.OpenYouTube
            "SEARCH_YOUTUBE" -> s("query").takeIf { it.isNotEmpty() }?.let { AppAction.SearchYouTube(it) }
            "OPEN_BROWSER" -> s("url", 500).takeIf { it.startsWith("https://") || it.startsWith("http://") }
                ?.let { AppAction.OpenBrowser(it) }
            "OPEN_DIALER" -> AppAction.OpenDialer(s("number", 20).takeIf { Regex("^[+0-9 ]{3,20}$").matches(it) })
            "OPEN_MAPS" -> s("query").takeIf { it.isNotEmpty() }?.let { AppAction.OpenMaps(it) }
            "OPEN_CAMERA" -> AppAction.OpenCamera
            "OPEN_SETTINGS" -> s("section", 20).uppercase().takeIf { it in settingsSections }
                ?.let { AppAction.OpenSettings(it) }
            "SAVE_NOTE" -> s("text", 2000).takeIf { it.isNotEmpty() }?.let { AppAction.SaveNote(it) }
            else -> null
        }
        return if (action == null) ParsedReply(reply, null, rejected = a.optString("type", "?"))
        else ParsedReply(reply, action)
    }
}
