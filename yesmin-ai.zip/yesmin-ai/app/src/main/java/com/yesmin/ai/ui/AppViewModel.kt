package com.yesmin.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yesmin.ai.actions.ActionExecutor
import com.yesmin.ai.actions.ActionRouter
import com.yesmin.ai.actions.AppAction
import com.yesmin.ai.actions.InstalledApp
import com.yesmin.ai.ai.ChatTurn
import com.yesmin.ai.ai.GeminiResult
import com.yesmin.ai.ai.GeminiService
import com.yesmin.ai.ai.Persona
import com.yesmin.ai.data.AppSettings
import com.yesmin.ai.data.MessageEntity
import com.yesmin.ai.data.MusicSearchEntity
import com.yesmin.ai.data.NoteEntity
import com.yesmin.ai.data.SettingsStore
import com.yesmin.ai.data.SnippetEntity
import com.yesmin.ai.data.YesminDb
import com.yesmin.ai.tools.ReminderScheduler
import com.yesmin.ai.voice.OrbState
import com.yesmin.ai.voice.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Connection { UNKNOWN, CONNECTED, ERROR }

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = SettingsStore(app)
    private val db = YesminDb.get(app)
    private val dao = db.dao()
    private val gemini = GeminiService()
    val executor = ActionExecutor(app)
    val voice = VoiceManager(app)

    val settings: StateFlow<AppSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val chat = dao.messages("chat").stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val code = dao.messages("code").stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val notes = dao.notes().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val snippets = dao.snippets().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val recentSearches = dao.recentSearches().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val orb: StateFlow<OrbState> = voice.state
    val voiceError: StateFlow<String?> = voice.voiceError

    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _connection = MutableStateFlow(Connection.UNKNOWN)
    val connection = _connection.asStateFlow()
    private val _status = MutableStateFlow<String?>(null)
    val status = _status.asStateFlow()
    private val _apps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val apps = _apps.asStateFlow()
    private val _favorites = MutableStateFlow<Set<String>>(emptySet())
    val favorites = _favorites.asStateFlow()

    private var job: Job? = null
    private var lastUserText: String? = null

    init {
        viewModelScope.launch {
            settings.collect { voice.configure(it.language, it.speechRate) }
        }
        _favorites.value = app.getSharedPreferences("favorites", 0).getStringSet("pkgs", emptySet()) ?: emptySet()
    }

    fun hasApiKey() = store.getApiKey().isNotBlank()
    fun apiKey() = store.getApiKey()
    fun clearStatus() { _status.value = null }

    // ---------- Chat ----------

    fun sendChat(text: String) {
        val t = text.trim()
        if (t.isEmpty()) { _status.value = "Pehle kuch likho ya bolo."; return }
        if (_busy.value) return
        lastUserText = t
        job = viewModelScope.launch {
            _busy.value = true
            voice.setThinking(true)
            dao.insertMessage(MessageEntity(scope = "chat", role = "user", text = t))
            val s = settings.value
            val history = dao.messages("chat").first().takeLast(20).map { ChatTurn(it.role, it.text) }
            val result = gemini.generate(store.getApiKey(), s, Persona.system(s.affection, s.language), history, jsonMode = true)
            when (result) {
                is GeminiResult.Failure -> {
                    _connection.value = Connection.ERROR
                    _status.value = result.message
                    voice.setThinking(false)
                }
                is GeminiResult.Success -> {
                    _connection.value = Connection.CONNECTED
                    val parsed = ActionRouter.parse(result.text)
                    var finalText = parsed.reply
                    parsed.action?.let { act ->
                        val r = if (act is AppAction.SaveNote) {
                            dao.insertNote(NoteEntity(text = act.text)); executor.execute(act)
                        } else {
                            if (act is AppAction.SearchYouTube) dao.insertSearch(MusicSearchEntity(query = act.query))
                            executor.execute(act)
                        }
                        finalText += "\n\n" + (if (r.success) "✅ " else "⚠️ ") + r.message
                    }
                    if (parsed.rejected != null) finalText += "\n\n⚠️ Yeh action supported nahi hai."
                    dao.insertMessage(MessageEntity(scope = "chat", role = "model", text = finalText))
                    voice.setThinking(false)
                    voice.speak(parsed.reply)
                }
            }
            _busy.value = false
        }
    }

    fun retryLast() { lastUserText?.let { sendChat(it) } }

    fun cancelRequest() {
        job?.cancel()
        _busy.value = false
        voice.setThinking(false)
    }

    fun startListening() = voice.startListening { sendChat(it) }
    fun stopListening() = voice.stopListening()
    fun stopSpeaking() = voice.stopSpeaking()
    fun clearVoiceError() = voice.clearError()

    // ---------- Coding assistant ----------

    fun sendCode(prompt: String, language: String, pastedCode: String) {
        val t = prompt.trim()
        if (t.isEmpty() && pastedCode.isBlank()) { _status.value = "Pehle request ya code daalo."; return }
        if (_busy.value) return
        job = viewModelScope.launch {
            _busy.value = true
            val full = buildString {
                append(t)
                if (pastedCode.isNotBlank()) append("\n\n```\n").append(pastedCode).append("\n```")
            }
            dao.insertMessage(MessageEntity(scope = "code", role = "user", text = full))
            val history = dao.messages("code").first().takeLast(12).map { ChatTurn(it.role, it.text) }
            when (val r = gemini.generate(store.getApiKey(), settings.value, Persona.coding(language), history, jsonMode = false)) {
                is GeminiResult.Failure -> _status.value = r.message
                is GeminiResult.Success -> {
                    _connection.value = Connection.CONNECTED
                    dao.insertMessage(MessageEntity(scope = "code", role = "model", text = r.text))
                }
            }
            _busy.value = false
        }
    }

    fun saveSnippet(language: String, code: String) = viewModelScope.launch {
        dao.insertSnippet(SnippetEntity(language = language, code = code))
        _status.value = "Snippet save ho gaya."
    }
    fun deleteSnippet(id: Long) = viewModelScope.launch { dao.deleteSnippet(id) }

    // ---------- Notes / music / apps ----------

    fun addNote(text: String) = viewModelScope.launch { if (text.isNotBlank()) dao.insertNote(NoteEntity(text = text.trim())) }
    fun deleteNote(id: Long) = viewModelScope.launch { dao.deleteNote(id) }

    fun quickAction(action: AppAction) {
        if (action is AppAction.SearchYouTube) viewModelScope.launch { dao.insertSearch(MusicSearchEntity(query = action.query)) }
        _status.value = executor.execute(action).message
    }

    fun openPackage(pkg: String) { _status.value = executor.openPackage(pkg).message }

    fun loadApps() = viewModelScope.launch {
        _apps.value = withContext(Dispatchers.Default) { executor.installedApps() }
    }

    fun toggleFavorite(pkg: String) {
        val n = _favorites.value.toMutableSet().also { if (!it.add(pkg)) it.remove(pkg) }
        _favorites.value = n
        getApplication<Application>().getSharedPreferences("favorites", 0).edit().putStringSet("pkgs", n).apply()
    }

    fun clearMusicHistory() = viewModelScope.launch { dao.clearSearches() }

    // ---------- Settings ----------

    fun saveSettings(s: AppSettings, apiKey: String) = viewModelScope.launch {
        store.save(s)
        if (apiKey.isNotBlank()) store.setApiKey(apiKey)
        _status.value = "Settings save ho gayi."
    }

    fun testConnection(s: AppSettings, apiKey: String) = viewModelScope.launch {
        _busy.value = true
        val key = apiKey.ifBlank { store.getApiKey() }
        when (val r = gemini.testConnection(key, s)) {
            is GeminiResult.Success -> { _connection.value = Connection.CONNECTED; _status.value = "Connected ✅" }
            is GeminiResult.Failure -> { _connection.value = Connection.ERROR; _status.value = r.message }
        }
        _busy.value = false
    }

    fun clearChatHistory() = viewModelScope.launch { dao.clearMessages("chat"); _status.value = "Chat history clear ho gayi." }
    fun clearAllLocalData() = viewModelScope.launch {
        dao.reminders().first().forEach { ReminderScheduler.cancel(getApplication(), it.id) }
        dao.clearAllMessages(); dao.clearNotes(); dao.clearSnippets(); dao.clearSearches(); dao.clearTodos(); dao.clearReminders()
        _status.value = "Saara local data delete ho gaya."
    }

    override fun onCleared() { voice.release() }
}
